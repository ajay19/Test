package com.challenge.code.models.impl;

import java.util.Collection;


import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.challenge.code.models.Breadcrumb;
import com.challenge.code.models.NavigationItem;
import com.day.cq.wcm.api.designer.Style;

@Model(adaptables = {SlingHttpServletRequest.class,Resource.class}, adapters = Breadcrumb.class, resourceType = "challenge/components/content/breadcrumb")
@Exporter(name = "jackson", extensions = "json")
public class BreadcrumbImpl implements Breadcrumb {
	private static final Logger LOG = LoggerFactory.getLogger(Breadcrumb.class);
    protected static final int PROP_START_LEVEL_DEFAULT = 2;
    protected static final boolean PROP_HIDE_CURRENT_DEFAULT = false;
    
    @ScriptVariable
    private Style currentStyle;
    
    @ScriptVariable
    private Page currentPage;
 
    private int startLevel;
    private boolean hideCurrent;
    private List<NavigationItem> items;
 
    @PostConstruct
    private void initModel() {
        startLevel = currentStyle.get(PN_START_LEVEL, PROP_START_LEVEL_DEFAULT);
        hideCurrent = currentStyle.get(PN_HIDE_CURRENT, PROP_HIDE_CURRENT_DEFAULT);
    }
    
	@Override
	public Collection<NavigationItem> getItems() {
        if (items == null) {
            items = new ArrayList<>();
            createNavigation();
        }
        return items;	
    }

    private List<NavigationItem> createNavigation() {
        int currentLevel = currentPage.getDepth();
        addNavigationItems(currentLevel);
        return items;
    }

    private void addNavigationItems(int currentLevel) {
        while (startLevel < currentLevel) {
            Page page = currentPage.getAbsoluteParent(startLevel);
            String currentPagePath = currentPage.getPath();
            if (page != null) {
                boolean isActivePage = page.equals(currentPage);
                if (isActivePage && hideCurrent) {
                    break;
                }
             // if currentPage is a descendant of Navigation Page
                boolean isHierarchyActive = currentPagePath.startsWith(page.getPath());
                String text = StringUtils.isNotBlank(page.getNavigationTitle()) ? page.getNavigationTitle() : page.getTitle();
                boolean hideInNav = page.isHideInNav();
                if (!hideInNav) {
                		NavigationItem navItem = new NavigationItemImpl(page, isActivePage, page.getPath(), text);
                		items.add(navItem);
                }
            }
            startLevel++;
        }
    }
	
}
