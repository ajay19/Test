package com.challenge.code.models;

import java.util.Collection;


public interface Breadcrumb {
	/**
     * Name of the resource property that will indicate from which level starting from the current page the items from the collection
     * returned by {@link #getItems()} will be accumulated.
     */
    String PN_START_LEVEL = "startLevel";
    /**
     * Name of the resource property that will indicate if the current page should not be present in the collection returned by
     * {@link #getItems()}.
     */
    String PN_HIDE_CURRENT = "hideCurrent";
        
    /**
     * Creates collection of pages(from site hierarchy of current page) for Global Navigation
     * Navigation Pages will be made up of direct children of navigation root specified by startLevel property
     * @return {@link Collection} of navigation items
     */
    Collection<NavigationItem> getItems();
}