package com.challenge.code.models.impl;

import com.challenge.code.models.NavigationItem;
import com.day.cq.wcm.api.Page;

public class NavigationItemImpl implements NavigationItem {

	
	private Page page;
    private boolean active;
    private boolean hierarchyActive;
    private String icon;
    private String url;
    private String text;
     
    public NavigationItemImpl(Page page, boolean active,  String url, String text) {
        this.page = page;
        this.active = active;
        this.url = url;
        this.text = text;
    }
    
    @Override
    public Page getPage() {
        return page;
    }
 
    @Override
    public boolean isActive() {
        return active;
    }
 
    @Override
    public boolean isHierarchyActive() {
        return hierarchyActive;
    }
 
    @Override
    public String getIcon() {
        return icon;
    }
 
    @Override
    public String getUrl() {
        return url;
    }
 
    @Override
    public String getText() {
        return text;
    }

 
  
}
