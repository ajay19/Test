# Code Challenge Project

This a content package project generated using the AEM Multimodule Lazybones template.

## Building

This project uses Maven for building. Common commands:

From the root directory, run ``mvn -PautoInstallPackage clean install`` to build the bundle and content package and install to a CQ instance.

From the bundle directory, run ``mvn -PautoInstallBundle clean install`` to build *just* the bundle and install to a CQ instance.



## Notes

- This project uses Editable templates for landing and articles.

- The level1 and level2 pages are created using landing template

- The level3 pages are created using article templates

- The breadcrumb component relies on the Page property "Hide In Nav" to include or exclude the page in breadcrumb. The project contains the code for the Breadcrumb component, the sling model and implementation for the display logic.

- Page "Level 2 Landing A" has the "Hide in Nav" set to true and hence that page and its child pages will not see that node in breadcrumb.



